import os
from PIL import Image

# Пути к папке проекта и папке с изображениями
project_path = os.path.abspath('.')
images_path = os.path.join(project_path, 'image')

# Определяем размер квадрата
size = 512

# Список изображений
images = []

# Проходим по всем изображениям в папке и добавляем их в список
for filename in os.listdir(images_path):
    filepath = os.path.join(images_path, filename)
    try:
        with Image.open(filepath) as image:
            # Масштабируем изображение по максимальной стороне
            width, height = image.size
            if width > height:
                new_width = size
                new_height = int(height / width * size)
            else:
                new_height = size
                new_width = int(width / height * size)
            image = image.resize((new_width, new_height))
            images.append(image)
    except:
        pass

# Создаем новое изображение, склеивая все изображения из списка
result_width = size * int(len(images) ** 0.5)  # вычисляем ширину итогового изображения
result_height = size * int(len(images) ** 0.5)  # вычисляем высоту итогового изображения
result_image = Image.new('RGB', (result_width, result_height))  # создаем пустое изображение

for i, image in enumerate(images):
    row = i // int(len(images) ** 0.5)  # вычисляем номер строки
    col = i % int(len(images) ** 0.5)  # вычисляем номер столбца
    result_image.paste(image, (col * size, row * size))  # вставляем изображение на позицию

# Сохраняем итоговое изображение
result_image_path = os.path.join(project_path, 'result.jpg')
result_image.save(result_image_path)

print(f"Итоговое изображение сохранено в {result_image_path}")
